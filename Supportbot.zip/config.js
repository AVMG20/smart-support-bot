require('dotenv').config()

module.exports = {
    token: 'NzI3MDc2MzgyODM1NzM2NjI2.Xvmkpg.gjXcCm3mkZzHp7N3CXXO-wj4d0M',

    bot: { // https://discordjs.guide/popular-topics/faq.html#how-do-i-check-if-a-guild-member-has-a-specific-role
        activity: 'PLAYING',
        activity_message: 'Smart Support',
        activity_status: 'online',
    },

    urls : {
        allowed_urls: [
            'https://bin.ptdl.co',
            'http://hastebin.com'
        ],
        max_content_size_in_bytes: 1048576, //1mb
    },

    images : {
        max_size_in_bytes : 2097152, //2mb
        parse_language : 'eng',
        message_reaction: '👀'
    },

    responses : [
        {
            key : /^(?=.*hello)(?=.*world).*$/mgi,
            content : `Hello World!`
        },
        {
            key : /^(?=.*how)(?=.*ssl).*$|(?=.*how)(?=.*https).*$/mgi,
            content : `There are many ways to add SSL to your site. A simple solution is to use certbot from let’s encrypt. cerbot will automatically install the certificates for you and keep your SSL certs up to date!
\`\`\`sudo add-apt-repository ppa:certbot/certbot
sudo apt-get update
sudo apt-get install python-certbot-nginx
sudo certbot --nginx -d yourdomain.com\`\`\``
        },
        {
            key : /^(?=.*how)(?=.*credits).*$|(?=.*credit)(?=.*system).*$/mgi,
            content : `The control panel uses a credit-based system.
credits are charged hourly based on the monthly price (price / 30 / 24)
This means that the price of your products won’t be charged right away when the user creates a server, but instead, the credits are reduced hourly—giving the user the option to cancel and create servers freely anytime.
When the user runs out of credits, his server will automatically be suspended.`
        },
        {
            key : /^(?=.*(how|add))(?=.*discord)(?=.*auth).*$/mgi,
            content : `We don’t have discord auth added as a login method because pterodactyl doesn’t have this either. Currently, our registration form automatically sends data to pterodactyl as well. So you get one login for both panels.
If we were to add discord login to our login form, you would still need to log in to pterodactyl.
This can be done using an ugly password generator on controlpanel. But this, kind of, still defeats the purpose of the convenient discord login since you still need to log in. 
Adding discord login to pterodactyl also requires extra work since I assume you don’t want random people to log into your pterodactyl panel while they haven’t registered on controlpanel yet (or are even banned from your controlpanel).
Because of this, we chose to have a standard login form linked to pterodactyl.`
        },
        {
            key : /^(?=.*using)(?=.*password)(?=.*no).*$/mgi,
            content : `It looks like you forgot to enter the password for your database in the \`.env\`
If the password contains any special characters sure to put it in 'quotes'`
        },
        {
            key : /^(?=.*have)(?=.*already)(?=.*made)(?=.*account).*$/mgi,
            content : `By default, we only allow users to make one account per IP address. to disable this,
head to \`/admin/configurations\` and set \`REGISTER_IP_CHECK\` to \`false\`. If you have proxied your domain through Cloudflare, then this check will always fail!`
        },
        {
            key : /^(?=.*how|get)(?=.*logs)(?=.*made)(?=.*account)|(?=.*500)(?=.*error).*$/mgi,
            content : `Can you please fetch the error logs, so we can assist you better regarding this error.
\`tail -n 100 /var/www/dashboard/storage/logs/laravel.log | nc bin.ptdl.co 99\``
        },
        {
            key : /^(?=.*how|get)(?=.*paypal)(?=.*client|secret).*$/mgi,
            content : `**How to get PayPal Client Id and Secret Key?**
1. Go to PayPal Developers Website home page.
2. Then Login to the dashboard.
3. Go to '[Your Name]', then go to 'Dashboard' in the top right corner.
4. Fill in the details for the new app and create a new app.
5. On the next page, you will be able to see your PayPal Client Id and secret.
source: https://www.knowband.com/blog/tips/get-paypal-client-id-secret/`
        },
        {
            key : /^(?=.*failed)(?=.*permission)(?=.*denied).*$/mgi,
            content : `Your panel does not have the right permissions, try giving it some :) 
\`sudo chmod -R 755 /var/www/dashboard\``
        },
        {
            key : /^(?=.*failed)(?=.*pterodactyl)(?=.*set-up)(?=.*correctly).*$/mgi,
            content : `It looks like your dashboard doesn’t have a valid pterodactyl API token set.
1. Head to your pterodactyl panel -> Application API
2. create a key with all permissions. 
3. add this key to your \`.env\` file \`sudo nano /var/www/dashboard/.env\``
        },
        {
            key : /^(?=.*invalid)(?=.*auth2).*$/mgi,
            content : `It seems that you haven't set up discord 0auth correctly, but fear not, the docs come to the rescue! https://controlpanel.gg/docs/Installation/additional-configuration#discord-auth
\n**Extra information about URL Formatting**
Any URL saved in your .env should never end with a \`/\`slash; controlpanel adds this \`/\` automatically to any URL, adding an extra 
 \`/\` will break the URL!

GOOD Example:
\`https://controlpanel.gg\`
BAD EXAMPLE:
\`https://controlpanel.gg/\`

When configuring discord-auth,  we will automatically use your APP_URL to create the appropriate URLs needed for discord-0auth. Make sure your URLs are correct!

When using SSL-Encryption (\`https://\`) double-check that all your URLs start with \`https://\` instead of \`http://\``
        }
    ]
}
